H1 headers:
Font: Monoton
Font color: #FFFFFF

p, a, and labels:
Font: Raleway
Font color: #FFFFFF

Button label:
Font: Raleway
Font color: #000000


CSS font family rules:
font-family: 'Monoton', cursive;
font-family: 'Raleway', sans-serif;



NOTES:
-go back and add href's to nav bar links.

-make pics on evidence page open in seperate page if clicked.
