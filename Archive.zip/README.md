# Danzig-Travolta
Website demonstrating that Glenn Danzig and John Travolta are in fact the same person!
